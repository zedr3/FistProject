package site.zedr.zedrSite.repo;

import org.springframework.data.repository.CrudRepository;
import site.zedr.zedrSite.Models.Post;

public interface PostRepo extends CrudRepository<Post, Long> {

}
