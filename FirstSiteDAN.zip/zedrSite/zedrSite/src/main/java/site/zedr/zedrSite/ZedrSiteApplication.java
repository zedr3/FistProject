package site.zedr.zedrSite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZedrSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZedrSiteApplication.class, args);
	}

}
