package site.zedr.zedrSite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZedrSiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
